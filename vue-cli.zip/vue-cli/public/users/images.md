Images from https://randomuser.me/photos.

*A copy of their copyright notice:*

**Copyright Notice**

All randomly generated photos were hand picked from the authorized section of UI Faces. Please visit UI Faces FAQ for 
more information regarding how you can use these faces.

*From UI Faces FAQ:*

**What can I use these faces for?**

Only mockups. Unless they're listed in the authorized section, those awesome folks allow their faces to be used on live products.