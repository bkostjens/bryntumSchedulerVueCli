<template>
    <div id="app">
        <header class="app-header">
            <h1><a href="..">Vue demo</a></h1>
            <label class="sel-event">Selected event: <span>{{ selectedEvent || 'None' }}</span></label>

            <div class="barmargin">
                <label>Barmargin:</label>
                <input min=0 max=10 type="number" v-model.number="barMargin">
            </div>
            <button @click="setToDaySpan">day</button>
            <button @click="setToWeekSpan">week</button>
            <button @click="backward"><i class="b-fa b-fa-backward"></i></button>
            <button @click="forward"><i class="b-fa b-fa-forward"></i></button>
            <button @click="addEvent"><i class="b-fa b-fa-plus"></i></button>
            <button class="red" @click="removeEvent" :disabled="selectedEvent == ''"><i class="b-fa b-fa-trash"></i>
            </button>
        </header>

        <scheduler
                ref="scheduler"
                :time-ranges-feature="true"
                :columns="columns"
                :row-height=60
                :bar-margin="barMargin"
                :events="events"
                :resources="resources"
                :time-ranges="timeRanges"
                :start-date="startDate"
                :end-date="endDate"
                :event-renderer="eventRenderer"
                event-style="colored"
                @eventselectionchange="onEventSelectionChange"
        >
        </scheduler>
    </div>
</template>

<script>
    import Scheduler from './components/Scheduler.vue';
    import {AjaxHelper} from './assets/scheduler.module.js';
    import moment from 'moment';

    export default {
        name : 'app',

        components : {
            Scheduler
        },

        data() {
            return {
                timeRangesFeature : true,

                days          : 7,
                events        : [],
                resources     : [],
                timeRanges    : [],

                barMargin     : 5,
                startDate     : new Date(2018, 1, 3, 8),
                endDate       : new Date(2018, 1, 10, 18),
                selectedEvent : '',
                columns       : [
                    {
                        type  : 'resourceInfo', imagePath : 'users/',
                        text  : 'Staff',
                        width : 130
                    },
                    {
                        text   : 'Type',
                        field  : 'role',
                        width  : 110,
                        editor : {
                            type     : 'combo',
                            items    : ['CEO', 'CTO', 'Sales', 'Tech Sales', 'Developer', 'Design & UX'],
                            editable : false
                        }
                    }
                ],

                eventRenderer : ({eventRecord}) => {
                    return `
                        <div class="info">
                            <div class="name">${eventRecord.name}</div>
                            <div class="desc">${eventRecord.desc}</div>
                        </div>
                     `;
                }
            };
        },

        methods : {
            setToWeekSpan: function() {
                this.days = 7;
                this.$refs.scheduler.schedulerEngine.viewPreset.shiftUnit = 'week';
                let startDate = moment(this.$refs.scheduler.schedulerEngine.viewportCenterDate).startOf('week').add(1,'days').toDate();
                let endDate = moment(startDate).add(this.days,'days').toDate();
                this.$refs.scheduler.schedulerEngine.setTimeSpan(startDate, endDate); 
            },

            setToDaySpan: function() {
                this.days = 1;
                this.$refs.scheduler.schedulerEngine.viewPreset.shiftUnit = 'day';
                let now = this.$refs.scheduler.schedulerEngine.viewportCenterDate;
                let startDate = moment(now).startOf('day').toDate();
                this.$refs.scheduler.schedulerEngine.setTimeSpan(startDate, moment(startDate).endOf('day').toDate());
            },

            forward: function() {
                this.$refs.scheduler.schedulerEngine.shiftNext()
                this.weeknumber = moment(this.$refs.scheduler.schedulerEngine.viewportCenterDate).week()
            },

            backward: function() {
                this.$refs.scheduler.schedulerEngine.shiftPrevious()
                this.weeknumber = moment(this.$refs.scheduler.schedulerEngine.viewportCenterDate).week()
            },

            getData() {
                AjaxHelper.get('./data/data.json').then(response => {
                    // Response has { resources, events, timeRanges }, can be applied directly
                    Object.assign(this, JSON.parse(response.response));
                });
            },

            addEvent() {
                this.$refs.scheduler.addEvent();
            },

            removeEvent() {
                this.$refs.scheduler.removeEvent();
                this.selectedEvent = '';
            },

            onEventSelectionChange({selection}) {
                if (selection.length) {
                    this.selectedEvent = selection[0].name;
                }
                else {
                    this.selectedEvent = '';
                }
            }
        },

        created() {
            this.getData();
        }
    };
</script>

<style>
    @font-face {
        font-family: "Source Sans Pro";
        src: url("assets/SourceSansPro-Regular.ttf.woff2") format("woff2"), url("assets/SourceSansPro-Regular.ttf.woff") format("woff");
        font-weight: 400;
    }

    html, body, #app {
        height: 100%;
    }

    body {
        visibility: unset;
        font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, sans-serif;
        font-size: 15px;
        margin: 0;
    }

    .app-header {
        padding: 1.5em .5em 1.5em 4em;
        background: url(../../_shared/images/logo_bryntum_bw.png) #2196F3;
        background-repeat: no-repeat;
        background-size: 30px;
        background-position: center left 1.5em;
        display: flex;
    }

    .app-header h1 {
        margin: 0;
        font-size: 1.5em;
        color: #fff;
        font-weight: normal;
        flex: 1;
        align-self: center;
    }

    .app-header a {
        color: inherit;
        text-decoration: none;
    }

    .app-header button {
        width: 2.8em;
        background: #8BC34A;
        border: none;
        color: #fff;
        cursor: pointer;
        font-size: 1em;
        font-family: "Source Sans Pro", "Helvetica Neue", Helvetica, sans-serif;
        border-radius: 2px;
        margin-right: .5em;
    }

    .app-header button:hover {
        background: #9CCC65;
    }

    .app-header button:active {
        background: #9CCC65;
    }

    .app-header button:disabled {
        background: #ccbdb8 !important;
        cursor: default;
    }

    .app-header button.red {
        background: #F44336;
    }

    .app-header button.red:hover {
        background: #EF5350;
    }

    .app-header .sel-event {
        margin-right: 2em;
        align-self: center;
        color: #fff;
    }

    .sel-event span {
        font-size: 1.1em;
    }

    .barmargin label {
        color: #fff;
        margin-right: .5em;
    }

    .barmargin input {
        font-size: 1em;
        font-family: inherit;
        padding: .7em;
        border-radius: 2px;
        border: none;
        margin-right: .5em;
    }

    .b-sch-range {
        background: repeating-linear-gradient(-55deg, #ddd, #ddd 10px, #eee 5px, #eee 20px);
        opacity: 0.5;
    }

    .info {
        flex-direction: column;
    }

    .desc {
        font-size: .8em;
        font-weight: 300;
    }
</style>
